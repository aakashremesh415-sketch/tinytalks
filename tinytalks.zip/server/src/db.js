import { PrismaClient } from '@prisma/client';
import { PrismaNeon } from '@prisma/adapter-neon';
import { Pool, neonConfig } from '@neondatabase/serverless';
import ws from 'ws';

// Neon's serverless driver needs a WebSocket implementation in Node
// (browsers/edge runtimes have one built in; plain Node doesn't).
neonConfig.webSocketConstructor = ws;

// Vercel reuses warm lambda containers between invocations, but a fresh
// module load (cold start, or `npm run dev` restart) would otherwise
// create a new pool every time. Cache on `globalThis` so a warm
// container reuses the same pool/client instead of leaking connections.
const globalForPrisma = globalThis;

function createClient() {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const adapter = new PrismaNeon(pool);
  return new PrismaClient({ adapter });
}

export const prisma = globalForPrisma.__tinytalksPrisma || createClient();

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.__tinytalksPrisma = prisma;
}
